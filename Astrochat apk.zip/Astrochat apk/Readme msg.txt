                                                                                           We Always Welcome the users for Astro Chat

# build version 
This app is still in Devloper preview There May be Bugs, We need a User Test Help Us to Find The Bugs And Ecceptions are Expected.This Will Be a Great Help For Us To Develop Further.Chat application establishes a connection between 2 or
more systems connected over an intra- net or ad-hoc. This tool can be used for large scale communication and conferencing in an organization or campus of vast size,thus increasing the standard of co-operation.

# System Architecture

This Application is built for both 32 and 64 bit program and for your kind information supported only for windows.For mac and linux soon will be released be patient
SYSTEM SPECIFICATION  
Hardware requirements In hardware requirement we require all those components which will provide us the platform for the development of the project. 
The minimum hardware required for the development of this project is as follows—
 Ram- minimum 1 GB
 Hard disk size—minimum 5 GB 
 Processor- i3 4-core 
These all are the minimum hardware requirement required for our project. We want to make our project to be used in any platform soon.Type of computer therefore we have taken minimum configuration to a large extent.128 MB ram is used 
so that we can execute our project in a least possible RAM.5 GB hard disk is used because project takes less space to be executed or stored. Therefore minimum hard disk is used.Others enhancements are according to the needs.
 Software requirements Software’s can be defined as programs which run on our computer .It is very important to run software to function the computer. Various software’s are needed in this project for its development.
 Operating system—Windows 8.1 
 Others—Visual Studio We will be using visual basic as our front hand because it is easier to use and provides features to the users which is used for the development of the project.
 system must have python pre-installed
 GPU - intel Hd graphics 

# SOFTWARE ARCHITECTURE 
 Socket Overview A socket is an object that represents a low level access point to the IP stack. This socket can be opened or closed or one of a set number of intermediate states. A socket can send and 
receive data down disconnection. Data is generally sent in blocks of few kilobytes at a time for efficiency; each of these block are called a packet. All packets that travel on the internet must use the Internet Protocol. This means 
that the source IP address, destination address must be included in the packet. Most packets also contain a port number. A port is simply a number between 1 and 65,535 that is used to differentiate higher protocols. Ports are 
important when it comes to programming your own network applications because no two applications can use the same port. Packets that contain port numbers come in two flavors: UDP and TCP/IP. UDP has lower latency than TCP/IP, 
especially on startup. Where data integrity is not of the utmost concerned, UDP can prove easier to use than TCP, but it should never be used where data integrity .

#Design Alternatives 
 Structured programming approach is used as the tool has been developed in Win64 and win32 platform. 
 Object Oriented approach is an alternative to this.
 Design Details At a minimum, the following should be described –
 a) Processing within modules We show a windows form application that makes communication graphic oriented and user friendly.
 b) Two GUI interfaces are captured  
 c) Design Alignment can vary for each computer we are still working on it
 d) Please turn off anti-virus

#features
login page
home page
Astro assitatnt
Chat room 

Login page:
create an account if you dont have an account with us username must be 20MIAxxxx
if you forget or want to change password press forget password

home page:
you can see our assistant button on below left
chat button on top right

# assitant command
you can ask to play song,time
you can ask for latest news or joke
ask it to open chat room
ask to search for a person
open browers,facebook,insta,twitter..

Note: as it is in devloping it may take some time so please wait...

.......Other features will updated later

Now We are leaving chat section alone as a devloper preview,plz send mail to gna.game@gmail.com for any queries or issues being faced.

Thank you for your support